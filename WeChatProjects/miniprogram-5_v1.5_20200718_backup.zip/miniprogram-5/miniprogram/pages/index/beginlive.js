// miniprogram/pages/index/beginlive.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    
    livebuttonname: "开始直播",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({
      title: '我的直播间',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
   
  },

  statechange:function(ret){
    if(ret.detail.code == 1002) {
      console.log('推流成功了',ret);
      wx.showToast({
        icon:'success',
        title: '直播已开始',
      })
    }
    else if(ret.detail.code == -1301){
      wx.showToast({
        icon:'none',
        title: '请打开摄像头权限',
      })
    }
    else if(ret.detail.code == -1302){
      wx.showToast({
        icon:'none',
        title: '请打开麦克风权限',
      })
    }
    else if(ret.detail.code == -1307){
      wx.showToast({
        icon:'none',
        title: '请检查网络是否正常',
      })
    }
  },

  onReady: function(){
    this.ctx = wx.createLivePusherContext('qmxlivepusher');
    
  },


  livebutton:function(){
    var that=this;
    if(this.data.livebuttonname=="开始直播"){
     
      this.ctx.start({
        success: function(ret){
                console.log('start push success!');
                that.setData({
                  livebuttonname:"停止直播"
                })
                wx.showToast({
                  icon:'success',
                  title: '直播已开始',
                })
            },
            fail: function(){
                console.log('start push failed!')
                wx.showToast({
                  icon:'none',
                  title: '开始直播异常',
                })
            },
            complete: function(){
                console.log('start push complete!')
            }
      });

    }
    else if(this.data.livebuttonname=="停止直播"){
      this.ctx.stop({
        success: function(ret){
                console.log('stop push success!');
                that.setData({
                  livebuttonname:"开始直播"
                })
                wx.showToast({
                  icon:'success',
                  title: '直播已停止',
                })
            },
            fail: function(){
                console.log('stop push failed!');
                wx.showToast({
                  icon:'none',
                  title: '停止直播异常',
                })
            },
            complete: function(){
                console.log('stop push complete!')
            }
      });
    }
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})