// miniprogram/pages/index/provincesmap/viewdetails.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var placeid = options.placeid;

    this.fetchplaceidfromdatabase(placeid);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  fetchplaceidfromdatabase: function(placeid){

    var that = this;
    var arr = new Array();

    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    db.collection('anhui').where({
      _id:placeid
    }).get({
      success: res => {
        this.setData({
          queryResult: JSON.stringify(res.data, null, 2)
        })
        console.log('[数据库] [查询记录] 成功: ', res)
        for(var i=0;i<res.data.length;i++){
          var haveimages = res.data[i].imagesfileID?"block":"none";
          var havevideos = res.data[i].videofileID?"block":"none";
          var haveshoppingimagefileID= res.data[i].shoppingimagefileID?"block":"none";
          this.setData({ 
                      title: res.data[i].title,
                      content: res.data[i].content,
                      itemid: res.data[i]._id,
                      fileID:res.data[i].imagesfileID,
                      videofileID:res.data[i].videofileID,
                      shoppingimagefileID:res.data[i].shoppingimagefileID,
                      haveimages:haveimages,
                      havevideos:havevideos,
                      haveshoppingimagefileID:haveshoppingimagefileID
                     });
          
            //console.log(res.data[i].imagesfileID);
         // console.log( res.data[i].problem);
         // console.log(res.data[i].answer);
        }
        
        wx.getSystemInfo({
          success: function (res) {
            that.setData({
              //view
              className_height: res.windowHeight / arr.length,
              //btn
              array: arr,
            })
          }
        }) 




      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '常见问题查询失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })


  }

})