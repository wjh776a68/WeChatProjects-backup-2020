// miniprogram/pages/index/provincesmap/addnewlist.js
var sha1 = require('../../../utils/sha1.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    titleCount: 0, //标题字数
    contentCount: 0, //正文字数
    title: '', //标题内容
    content: '', //正文内容
    avatarUrl:"",
    images: []
    
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  chooseImage(e) {
    wx.chooseImage({
      sizeType: ['original', 'compressed'],  //可选择原图或压缩后的图片
      sourceType: ['album', 'camera'], //可选择性开放访问相册、相机
      success: res => {
        const images = this.data.images.concat(res.tempFilePaths)
        // 限制最多只能留下3张照片
       // this.data.images = images.length <= 3 ? images : images.slice(0, 3) 
        this.setData({
          images: images.length <= 3 ? images : images.slice(0, 3) 
        })
      }
    })
  },

  removeImage(e) {
    const idx = e.target.dataset.idx
    // this.data.images.splice(idx, 1)
    this.setData({
      images: []
    })  
  },

  handleImagePreview(e) {
    const idx = e.target.dataset.idx
    const images = this.data.images
    wx.previewImage({
      current: images[idx],  //当前预览的图片
      urls: images,  //所有要预览的图片
    })
  },


  handleTitleInput(e) {
    const value = e.detail.value
    //this.data.title = value
    //this.data.titleCount = value.length  //计算已输入的标题字数
    this.setData({
      title:value,
      titleCount:value.length
    })
  },

  handleContentInput(e) {
    const value = e.detail.value
   // this.data.content = value
   // this.data.contentCount = value.length  //计算已输入的正文字数
   // $digest(this)
    this.setData({
      content:value,
      contentCount:value.length
    })
  },


  submitForm(e) {
    const title = this.data.title
    const content = this.data.content

    if (title && content) {
      wx.showLoading({
        title: '正在发表...',
        mask: true
      })
      
      if(this.data.images.length!=0){
        const posterfilePath = this.data.images[0]
       

        var posterfilePathsha1 = sha1.sha1(posterfilePath); 
      


        // 上传图片
        const cloudPath = 'IMG' + posterfilePathsha1.toString();//filePath.match(/\.[^.]+?$/)[0]
        wx.cloud.uploadFile({
          cloudPath,
          filePath,
          success: res => {
            console.log('[上传文件] 成功：', res)
  
           // app.globalData.fileID = res.fileID
           // app.globalData.cloudPath = cloudPath
           // app.globalData.imagePath = filePath
            
            //wx.navigateTo({
            //  url: '../storageConsole/storageConsole'
            //})
            uploadshoppingfilepath(res.fileID);
            //this.onGetOpenid(res.fileID);
          },
          fail: e => {
            console.error('[上传文件] 失败：', e)
            wx.showToast({
              icon: 'none',
              title: '上传失败',
            })
          },
          complete: () => {
            wx.hideLoading()
          }
        })
  
      }
      else{
        this.onGetOpenid(null);
        wx.hideLoading();
      }
    }
    else if(!title){
      wx.showToast({
        icon:'none',
        title: '标题不应为空',
      })
    }
    else if(!content){
      wx.showToast({
        icon:'none',
        title: '正文不应为空',
      })
    }
  },


  uploadshoppingfilepath: function(postfilepathid){
    const shoppingfilePath = this.data.images[1]
    
    var shoppingfilePathsha1 = sha1.sha1(shoppingfilePath); 
   
    const cloudPath = 'IMG' + shoppingfilePathsha1.toString();//filePath.match(/\.[^.]+?$/)[0]
      wx.cloud.uploadFile({
        cloudPath,
        filePath,
        success: res => {
          console.log('[上传文件] 成功：', res)

        // app.globalData.fileID = res.fileID
        // app.globalData.cloudPath = cloudPath
        // app.globalData.imagePath = filePath
          
          //wx.navigateTo({
          //  url: '../storageConsole/storageConsole'
          //})
          uploadvideofilepath(postfilepathid,res.fileID);
          //this.onGetOpenid(res.fileID);
        },
        fail: e => {
          console.error('[上传文件] 失败：', e)
          wx.showToast({
            icon: 'none',
            title: '上传失败',
          })
        },
        complete: () => {
          wx.hideLoading()
        }
      })

   
  
  },

  
  uploadvideofilepath: function(postfilepathid,shoppingfilepathid){
   
    const videofilePath = this.data.images[2]
   
    var videofilePathsha1 = sha1.sha1(videofilePath); 
    const cloudPath = 'IMG' + videofilePathsha1.toString();//filePath.match(/\.[^.]+?$/)[0]
      wx.cloud.uploadFile({
        cloudPath,
        filePath,
        success: res => {
          console.log('[上传文件] 成功：', res)

        // app.globalData.fileID = res.fileID
        // app.globalData.cloudPath = cloudPath
        // app.globalData.imagePath = filePath
          
          //wx.navigateTo({
          //  url: '../storageConsole/storageConsole'
          //})

          this.onGetOpenid(postfilepathid,shoppingfilepathid,res.fileID);
        },
        fail: e => {
          console.error('[上传文件] 失败：', e)
          wx.showToast({
            icon: 'none',
            title: '上传失败',
          })
        },
        complete: () => {
          wx.hideLoading()
        }
      })

   
  
  }


})