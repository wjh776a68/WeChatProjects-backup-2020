// miniprogram/pages/myinform/bindaccount.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    schoolid:"",
    schoolname:"",
    phonenumber:"",
    qqnumber:"",
    avatarUrl:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
        // 获取用户信息
        wx.setNavigationBarTitle({
          title: '绑定学校账户',
        })
        wx.getSetting({
          success: res => {
            if (res.authSetting['scope.userInfo']) {
              // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
              wx.getUserInfo({
                success: res => {
                  this.setData({
                    avatarUrl: res.userInfo.avatarUrl,
                    
                  })
                }
              })
            }
          }
        })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  isbinded: function(testschoolid){
    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    db.collection('usersdata').where({
      schoolid: testschoolid
    }).get({
      success: res => {
        this.setData({
          queryResult: JSON.stringify(res.data, null, 2)
        })
      //  console.log(res.data.length);
        console.log('[数据库] [查询记录] 成功: ', res);
        if(res.data.length==0){
          return false;
        }else{
          return true;
        }
       // 
     //   return false;
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '网络问题，绑定失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
        return true;
      }
    })
  },
  

  submitbindaccount: function(e){
    console.log(e.detail.value);

    let { schoolname, schoolid, phonenumber, qqnumber } = e.detail.value;
 
    if(!schoolname){
      wx.showToast({
        icon:'none',
        title: '姓名不应为空',
      })
    }else if(!schoolid){
      wx.showToast({
        icon:'none',
        title: '学号不应为空',
      })
    } else if(this.isbinded(schoolid)==true){
      wx.showToast({
        icon:'none',
        title: '该学号已绑定',
      })
    }else{
      const db = wx.cloud.database()
      db.collection('usersdata').add({
        data: {
          schoolid:    schoolid,
          schoolname:  schoolname,
          phonenumber: phonenumber,
          qqnumber:    qqnumber,
          avatarUrl:   this.data.avatarUrl
          //count: 1
        },
        success: res => {
          // 在返回结果中会包含新创建的记录的 _id
         // this.setData({
            //counterId: res._id,
            //count: 1
         // })
          wx.showToast({
            icon:'success',
            title: '绑定成功',
          })
          console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
          setTimeout(function () {
            wx.navigateBack({
              complete: (res) => {},
            })
           }, 1500) 
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '学号已绑定'
          })
          console.error('[数据库] [新增记录] 失败：', err)
        }
      })

    }
    

   
  }
})

 