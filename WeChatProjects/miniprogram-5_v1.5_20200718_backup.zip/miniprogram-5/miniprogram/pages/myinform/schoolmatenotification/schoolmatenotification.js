// miniprogram/pages/myinform/schoolmatenotification.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  onGetOpenid:  function() {
    // 调用云函数
   wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('[云函数] [login] user openid: ', res.result.openid)
        
        this.openid2schoolid(res.result.openid);
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
        return null;
      }
    })
  },

  openid2schoolid:  function(thisopenid){

    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    return   db.collection('usersdata').where({
      _openid: thisopenid
    }).get({
      success: res => {
        this.setData({
          queryResult: JSON.stringify(res.data, null, 2)
        })
      //  console.log(res.data.length);
        console.log('[数据库] [查询记录] 成功: ', res);
        if(res.data.length==0){
          wx.showToast({
            icon: 'none',
            title: '请先绑定学校账号'
          })
          return null;
        }else{
          this.fetchproblemfromdatabase(res.data[0].schoolid);
        }
       // 
     //   return false;
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '网络问题，查询失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
        
        return null;
      }
    })

  },


  fetchproblemfromdatabase: function(schoolid){
    var that = this;
    var arr = new Array();

    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    db.collection('usersrelation').get({
      success: res => {
        this.setData({
          queryResult: JSON.stringify(res.data, null, 2)
        })
        console.log('[数据库] [查询记录] 成功: ', res)

        
        for(var i=0;i<res.data.length;i++){
          //console.log("schoolid" + schoolid);
         // console.log(res.data[i].schoolidbind.spilt('.')[0]);
          var name=res.data[i].schoolidbind.spilt('.');
         // console.log("name" + name);
        
          if(name[0]==schoolid.toString()){
            console.log("rr");
            res.data[i].otherschoolid=name[1];
            arr.push({ otherschoolid: res.data[i].otherschoolid});
          }else if(name[1]==schoolid.toString()){ 
            console.log("rr");
            res.data[i].otherschoolid=name[0];
            arr.push({ otherschoolid: res.data[i].otherschoolid});
          }
          else{
            console.log("rr");
          }
         
          

         // console.log( res.data[i].problem);
         // console.log(res.data[i].answer);
        }
        
        wx.getSystemInfo({
          success: function (res) {
            that.setData({
              //view
              className_height: res.windowHeight / arr.length,
              //btn
              array: arr,
            })
          }
        }) 
        console.log("end");



      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '好友列表加载失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({title:'好友消息'});
    this.onGetOpenid();
   

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})