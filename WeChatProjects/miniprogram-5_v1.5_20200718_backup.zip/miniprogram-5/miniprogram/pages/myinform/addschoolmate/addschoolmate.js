//由于微信小程序只能使用垃圾的过程式语言，不能调用自定义函数。因此这里全部使用面向过程方式设计，垃圾腾讯
// miniprogram/pages/myinform/addschoolmate.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    SearchData:{
      value:"",
    }

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({title:'添加好友'});
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  
  
  isbinded: function(testschoolid){

    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    var result = db.collection('usersdata').where({
      schoolid: testschoolid
    }).get({
      success: res => {
        this.setData({
          queryResult: JSON.stringify(res.data, null, 2)
        })
      //  console.log(res.data.length);
        console.log('[数据库] [查询记录] 成功: ', res);
        if(res.data.length==0){
          wx.showToast({
            icon: 'none',
            title: '未找到指定学生',
          })
          console.log("fasle");
          //return false;
        }else{
          console.log("true");
          //return true;
          this.bindschoolmate(testschoolid);
        }
        
       // 
     //   return false;
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '网络问题，添加失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
        console.log("true");
        //return true;
      }

      
    })
    
    console.log("log" + result);
    return result;
  },

  onGetOpenid:  function(myopenid) {
    // 调用云函数
   wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {
        console.log('[云函数] [login] user openid: ', res.result.openid)
        console.log(myopenid);
        this.openid2schoolid(res.result.openid,myopenid);





      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
        return null;
      }
    })
  },

  SearchInput: function(e){
   
  },

  openid2schoolid:  function(thisopenid,otherschoolid){

    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    return   db.collection('usersdata').where({
      _openid: thisopenid
    }).get({
      success: res => {
        this.setData({
          queryResult: JSON.stringify(res.data, null, 2)
        })
      //  console.log(res.data.length);
        console.log('[数据库] [查询记录] 成功: ', res);
        if(res.data.length==0){
          wx.showToast({
            icon: 'none',
            title: '请先绑定学校账号'
          })
          return null;
        }else{
         
         



        var myschoolid =  res.data[0].schoolid;
        console.log(myschoolid);
       
        var schoolidbind;
        console.log(typeof(otherschoolid));
        if(myschoolid<otherschoolid){
          schoolidbind=myschoolid + "." + otherschoolid;
          console.log("schoolidbind" + schoolidbind);
        }
        else if(myschoolid>otherschoolid){
          schoolidbind= otherschoolid  + "." + myschoolid;
          console.log("schoolidbind" + schoolidbind);
        }
        else{
          wx.showToast({
            icon:'none',
            title: '无法添加自身'
          })
          return;
        }
        console.log("schoolidbind" + schoolidbind);
    
        const db = wx.cloud.database()
        db.collection('usersrelation').add({
          data: {
            schoolidbind: schoolidbind
          },
          success: res => {
            // 在返回结果中会包含新创建的记录的 _id
            this.setData({
              counterId: res._id,
              count: 1
            })
            wx.showToast({
              icon: 'success',
              title: '已添加为好友',
            })

            setTimeout(function () {
              wx.navigateBack({
                complete: (res) => {},
              })
             }, 1500) 
            console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
          },
          fail: err => {
            wx.showToast({
              icon: 'none',
              title: '已在好友列表中'
            })
            console.error('[数据库] [新增记录] 失败：', err)
          }
        })







        }
       // 
     //   return false;
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '网络问题，添加失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
        
        return null;
      }
    })

  },

  schoolid2openid:  function(schoolid){
    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    return  db.collection('usersdata').where({
      schoolid: schoolid
    }).get({
      success: res => {
        this.setData({
          queryResult: JSON.stringify(res.data, null, 2)
        })
      //  console.log(res.data.length);
        console.log('[数据库] [查询记录] 成功: ', res);
        if(res.data.length==0){
        
          return null;
        }else{
         
          return res.data[0]._openid;
        }
       // 
     //   return false;
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '网络问题，添加失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
        
        return null;
      }
    })
  },

  bindschoolmate:  function(schoolid){
    
   this.onGetOpenid(schoolid);

  },



  SearchConfirm: function(e){

      var searchcondition=e.detail.value;

     
     // var myopenid = this.onGetOpenid();
    
      this.isbinded(searchcondition);
  
         
          

  }
})


