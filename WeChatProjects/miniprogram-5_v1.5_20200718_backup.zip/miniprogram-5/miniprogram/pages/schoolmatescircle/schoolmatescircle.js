// pages/schoolmatescircle/schoolmatescircle.js

Page({

  /**
   * 页面的初始数据
   */
  data: {
    currentTab: 0,
    peoplenumber: 0,

    pagescrolltop: 0,
    windowsheight: 900,
    scrollTop: 0
  },

  
  addnew: function(){
    
    wx.navigateTo({
      url: 'addnewmessage',
    })
  },
  
  
    //滑动切换
    swiperTab: function (e) {
      var that = this;
      that.setData({
        currentTab: e.detail.current
      });
    },
    //点击切换
    clickTab: function (e) {
      var that = this;
      if (this.data.currentTab === e.target.dataset.current) {
        return false;
      } else {
        that.setData({
          currentTab: e.target.dataset.current
        })
      }
    },

    regionchange(e) {
      console.log(e.type)
    },
    markertap(e) {
      //console.log(e.detail.markerId)
     
      switch(e.detail.markerId){
        case 0:console.log("receive 0");break;
        case 1:console.log("receive 1");break;
        default:
          console.log("error");
      }
    },
    controltap(e) {
      console.log(e.detail.controlId);
      console.log("hello");
      wx.getLocation({
        type: 'wgs84',
        success (res) {
          const latitude = res.latitude
          const longitude = res.longitude
          const speed = res.speed
          const accuracy = res.accuracy
         
        }
        
       })
    },

  jumptogonggao: function(){
    wx.navigateTo({
      url: '../myinform/microR/microR',
    })
  },

  jumptowenda: function(){
    wx.navigateTo({
      url: '../myinform/help/help',
    })
  },


  fetchproblemfromdatabase: function(){
    var that = this;
    var arr = new Array();

    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    db.collection('schoolmatescircle').get({
      success: res => {
        this.setData({
          queryResult: JSON.stringify(res.data, null, 2)
        })
        console.log('[数据库] [查询记录] 成功: ', res)
        for(var i=0;i<res.data.length;i++){
          var haveimages = res.data[i].imagesfileID?"block":"none";
          arr.push({ schoolname: res.data[i].schoolname, 
                      author: res.data[i].schoolid,
                      title: res.data[i].title,
                      content: res.data[i].content,
                      like:res.data[i].like,
                      updatetime:res.data[i].updatetime,
                      authoravatarUrl:res.data[i].avatarUrl,
                      fileID:res.data[i].imagesfileID,
                      haveimages:haveimages });
          
            console.log(res.data[i].imagesfileID);
         // console.log( res.data[i].problem);
         // console.log(res.data[i].answer);
        }
        
        wx.getSystemInfo({
          success: function (res) {
            that.setData({
              //view
              className_height: res.windowHeight / arr.length,
              //btn
              array: arr,
            })
          }
        }) 




      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '常见问题查询失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })

  },

  handleImagePreview(e) {
    console.log(e);
    var urls = [];
    urls[0]=e.target.id;
    wx.previewImage({
      current: e.target.id,  //当前预览的图片
      urls: urls,  //所有要预览的图片
    })
  },

  addlove:function(e){
    // console.log(e);
     //console.log(e.target.id);
    // console.log(e.target.dataset['index']);
     var that = this;
    // var arr = new Array();
     var newlike = parseInt(e.target.dataset['index'])+1;
    // console.log(newlike);
     const db = wx.cloud.database()
     // 查询当前用户所有的 counters
     db.collection('schoolmatescircle').where({
         updatetime:e.target.id
     }).update({
       data: {
         like: newlike,
         //updatetime:""
         //count: 1
       },
 
       success: res => {
         this.setData({
           queryResult: JSON.stringify(res.data, null, 2)
         })
 
         wx.showToast({
           title: '点赞成功',
         })
         this.fetchproblemfromdatabase();
         console.log('[数据库] [查询记录] 成功: ', res);
         
       },
       fail: err => {
         wx.showToast({
           title: '点赞失败',
         })
         console.error('[数据库] [查询记录] 失败：', err);
       }
     })
   },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
   // wx.setNavigationBarTitle({title:'启明星'});
    //this.fetchproblemfromdatabase();

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      windowsheight: wx.getSystemInfoSync().windowHeight
    });
   
    this.fetchpeoplenumberfromdatabase();
     this.fetchproblemfromdatabase();
  },


  
  fetchpeoplenumberfromdatabase: function(){
    var that = this;
    var arr = new Array();

    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    db.collection('usersdata').get({
      success: res => {
        this.setData({
          queryResult: JSON.stringify(res.data, null, 2)
        })
        console.log('[数据库] [查询记录] 成功: ', res)
        
        //res.data.length=100000;

        if(res.data.length<10000){
          this.setData({
            peoplenumber:res.data.length
          })
        }
        else if(res.data.length<100000000){
         
          this.setData({
            peoplenumber:String(parseInt(res.data.length/10000)) + "w+"
          })
        }
        else{
          this.setData({
            peoplenumber:"Number of human-being"
          })
        }
       

      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '网络问题，加载失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
      
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  onPageScroll: function(e) {
    console.log(e.scrollTop);
    this.setData({ 
      pagescrolltop: e.scrollTop
    });
  },

  scroll : function(e){
    console.log(e.detail.scrollTop);
    if(this.data.pagescrolltop<100){

      // this.setData({
      //   scrollTop: 0
      // });

      wx.pageScrollTo({
        scrollTop: this.data.windowsheight * 0.35
      });

      
     
      
      
    }

  }




})