// miniprogram/pages/schoolmatescircle/addnewmessage.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    avatarUrl:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              this.setData({
                avatarUrl: res.userInfo.avatarUrl,
                
              })
            }
          })
        }
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  
  
  onGetOpenid:  function(e) {
    // 调用云函数
   wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {


        this.openid2schoolid(res.result.openid,e);
      },
      fail: err => {

        return null;
      }
    })
  },

  openid2schoolid:  function(thisopenid,e){

    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    return   db.collection('usersdata').where({
      _openid: thisopenid
    }).get({
      success: res => {
        this.setData({
          queryResult: JSON.stringify(res.data, null, 2)
        })

        if(res.data.length==0){
          wx.showToast({
            icon: 'none',
            title: '请先绑定学校账号'
          })
          return null;
        }else{
          this.submitproblem(e,res.data[0].schoolid,res.data[0].schoolname);
        }

      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '网络问题，发送失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
        
        return null;
      }
    })

  },

  submitproblem: function(e,schoolid,schoolname){

    let problem = e.detail.value.content;
    let title =  e.detail.value.title;


    if(!problem){
      wx.showToast({
        icon:'none',
        title: '请输入动态内容',
      })
    }else{
      var dateTime = new Date();
      var years = dateTime.getFullYear();//获取年份
      var months = dateTime.getMonth()+1;//获取月份
      var dates = dateTime.getDate();//获取天
      var week=new Array('星期日','星期一','星期二','星期三','星期四','星期五','星期六');
      var day = dateTime.getDay();
      var hours = dateTime.getHours();//获取小时
      var minutes = dateTime.getMinutes();//获取分钟
      var seconds = dateTime.getSeconds();//获取秒
      if(hours<10){
        hours = "0" + hours.toString();
      }
      if(minutes<10){
        minutes = "0" + minutes.toString();
      }
      if(dates<10){
        dates = "0" + dates.toString();
      }
      if(months<10){
        months = "0" + months.toString();
      }

      var timestring = years+ "/" +months+ "/" +dates + " " +  hours + ":" + minutes;
      timestring = timestring.toString();

      const db = wx.cloud.database()
      db.collection('microR').add({
        data: {
          title: title,
          content:    problem,
          updatetime: timestring,//getDate(),
          schoolid: schoolid,
          avatarUrl: this.data.avatarUrl,
          schoolname:schoolname,
          iconfileID:'cloud://qmx.716d-qmx-1302572747/microRDefaultNotificationIcon.png',
          imagesfileID:'',
          videofileID:'',
          //like:0
          //updatetime:""
          //count: 1
        },
        success: res => {
          // 在返回结果中会包含新创建的记录的 _id
         // this.setData({
            //counterId: res._id,
            //count: 1
         // })
          wx.showToast({
            icon:'success',
            title: '发送成功',
          })
          setTimeout(function () {
            wx.navigateBack({
              complete: (res) => {},
            })
           }, 1500) 

        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '发送失败'
          })

        }
      })

    }
  }

})