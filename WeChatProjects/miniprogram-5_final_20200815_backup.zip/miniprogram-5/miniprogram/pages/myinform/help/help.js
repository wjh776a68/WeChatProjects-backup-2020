// miniprogram/pages/myinform/help.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  

  fetchproblemfromdatabase: function(){
    var that = this;
    var arr = new Array();

    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    db.collection('problemdata').where({
      _openid: this.data.openid
    }).get({
      success: res => {
        this.setData({
          queryResult: JSON.stringify(res.data, null, 2)
        })

        for(var i=0;i<res.data.length;i++){
          if(!res.data[i].answer){
            res.data[i].answer="暂无答案";
          }
          arr.push({ problem: res.data[i].problem,answer: res.data[i].answer,author:res.data[i].schoolid,updatetime:res.data[i].updatetime });
          

        }
        
        wx.getSystemInfo({
          success: function (res) {
            that.setData({
              //view
              className_height: res.windowHeight / arr.length,
              //btn
              array: arr,
            })
          }
        }) 




      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '常见问题查询失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.setNavigationBarTitle({title:'常见问题'});
    this.fetchproblemfromdatabase();
  

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})