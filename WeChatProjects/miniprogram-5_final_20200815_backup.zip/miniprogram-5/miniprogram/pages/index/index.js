//index.js
//获取应用实例
const app = getApp()

Page({

  data: {
    maplongitude:104,
    maplatitude:20,
    mapscale:3,

    isShowConfirm:false,

    fullScreenFlag:false,
    isstoplive:true,

    avatarUrl: './user-unlogin.png',
    userInfo: null,
    logged: false,
    takeSession: false,
    requestResult: '',
    // chatRoomEnvId: 'release-f8415a',
    chatRoomCollection: 'chatroom',
    chatRoomGroupId: 'demo',
    chatRoomGroupName: '聊天室',

    // functions for used in chatroom components
    onGetUserInfo: null,
    getOpenID: null,
   
    currentTab: 0,
    //motto: 'Hello World',
   // userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),

    markers: [{ 
      id: 0,
      latitude: 32,
      longitude: 117,
      width: 50,
      height: 70,
      //iconPath:'images/anhui.png',
      callout: {
        content: '安徽省',  //文本
        color: '#FF0202',  //文本颜色
        borderRadius: 3,  //边框圆角

        borderWidth: 1,  //边框宽度
        borderColor: '#FF0202',  //边框颜色
        bgColor: '#ffffff',  //背景色
        padding: 5,  //文本边缘留白
        textAlign: 'center'  //文本对齐方式。有效值: left, right, center
      }
    }
  
  ],

    polyline: [{
      // points: [{
      //   longitude: 113.3245211,
      //   latitude: 23.10229
      // }, {
      //   longitude: 113.324520,
      //   latitude: 23.21229
      // }],
      // color:"#FF0000DD",
      // width: 2,
      // dottedLine: true
    }],
    // controls: [{
    //   id: 999,
    //   iconPath: '/images/position.jpg',
    //   position: {
    //     left: 0,
    //     top: 400-50,
    //     width: 50,
    //     height: 50
    //   },
    //   clickable: true
    // }],

    isadmintoshow:"none",
    

  },


  
  getopenidthenfetchadminfromdatabase:function(){
    // 调用云函数
    wx.cloud.callFunction({
     name: 'login',
     data: {},
     success: res => {


       this.fetchadminfromdatabase( res.result.openid);
     },
     fail: err => {
       console.error('[云函数] [login] 调用失败', err);
       
     }
   })
 },

 addnewlive: function(){
   wx.navigateTo({
     url: 'beginlive',
   })
 },
 
 statechange:function(ret){
  if(ret.detail.code == 2004) {

    wx.showToast({
      icon:'success',
      title: '正在观看直播',
    })
  }
  else if(ret.detail.code == -2301) {
    wx.showToast({
      icon:'none',
      title: '当前没有直播',
    })
    this.setData({
      isstoplive:true
    });
  }
  else if(ret.detail.code == 2006){
    wx.showToast({
      icon:'none',
      title: '直播结束，感谢观看',
    })
    this.setData({
      isstoplive:true
    });
  }

 },

 fetchadminfromdatabase: function(openid){
   var that = this;
   var arr = new Array();
  
   const db = wx.cloud.database()
   // 查询当前用户所有的 counters
   db.collection('superusers').get({
     success: res => {
       this.setData({
         queryResult: JSON.stringify(res.data, null, 2)
       })
      
    
       for(var i=0;i<res.data.length;i++){
  
         if(res.data[i].adminopenid==openid){
           
           wx.getSystemInfo({
             success: function (res) {
               that.setData({
                 isadmintoshow:"block"
               })
             }
           }) 
           break;

         }
        
       }
       
       


     },
     fail: err => {
      
       console.error('[数据库] [查询记录] 失败：', err)
     }
   })

 },



  fullScreen: function() {
    var that = this;
    //全屏
    var vidoHeight = wx.getSystemInfoSync().windowHeight;
    var fullScreenFlag = that.data.fullScreenFlag;
    if (fullScreenFlag) {
      fullScreenFlag = false;
    } else {
      fullScreenFlag = true;
    }
    if (fullScreenFlag) {
      //全屏
      that.PlayerCtx.requestFullScreen({
        success: res => {
            that.setData({
              fullScreenFlag: fullScreenFlag
            });
           
        },
        fail: res => {
         
        }
      });

    } else {
      //缩小
      that.PlayerCtx.exitFullScreen({
        success: res => {
         
          that.setData({
            fullScreenFlag: fullScreenFlag
          });
        },
        fail: res => {
       
        }
      });
    }
  
  },

  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },

  onLoad: function () {
   // document.getElementById("map").style.height=;
   // this.setData({"mapheight": wx.getSystemInfoSync().screenHeight});
// mapheight: wx.getSystemInfoSync().windowHeight-50,
   
    // if (app.globalData.userInfo) {
    //   this.setData({
    //     userInfo: app.globalData.userInfo,
    //     hasUserInfo: true
    //   })
    // } else if (this.data.canIUse){
    //   // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
    //   // 所以此处加入 callback 以防止这种情况
    //   app.userInfoReadyCallback = res => {
    //     this.setData({
    //       userInfo: res.userInfo,
    //       hasUserInfo: true
    //     })
    //   }
    // } else {
    //   // 在没有 open-type=getUserInfo 版本的兼容处理
    //   wx.getUserInfo({
    //     success: res => {
    //       app.globalData.userInfo = res.userInfo
    //       this.setData({
    //         userInfo: res.userInfo,
    //         hasUserInfo: true
    //       })
    //     }
    //   })
    // }


    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          // 已经授权，可以直接调用 getUserInfo 获取头像昵称，不会弹框
          wx.getUserInfo({
            success: res => {
              this.setData({
                avatarUrl: res.userInfo.avatarUrl,
                userInfo: res.userInfo
              })
            }
          })
        }
      }
    })

    this.setData({
      onGetUserInfo: this.onGetUserInfo,
      getOpenID: this.getOpenID,
    })

    wx.getSystemInfo({
      success: res => {
     
        if (res.safeArea) {
          const { top, bottom } = res.safeArea
          this.setData({
            //containerStyle: `padding-top: ${(/ios/i.test(res.system) ? 10 : 20) + top}px; padding-bottom: ${20 + res.windowHeight - bottom}px`,
            
          })
        }
      },
    })



    this.fetchproblemfromdatabase();

    this.getopenidthenfetchadminfromdatabase();
  },


  onReady(res) {
    this.ctx = wx.createLivePlayerContext('qmxliveplayer');
  },

  bindPlay() {
    this.setData({
      isstoplive:false
    });

    this.ctx.play({
      success: res => {
     
      },
      fail: res => {
 
      }
    })
  },
  bindPause() {
    this.setData({
      isstoplive:true
    });

    this.ctx.pause({
      success: res => {
       
      },
      fail: res => {
       
      }
    })
  },
  bindStop() {
    this.setData({
      isstoplive:true
    });

    this.ctx.stop({
      success: res => {

      },
      fail: res => {
    
      }
    })
  },
  bindResume() {
    this.setData({
      isstoplive:true
    });

    this.ctx.resume({
      success: res => {

      },
      fail: res => {
   
      }
    })
  },
  bindMute() {
    this.ctx.mute({
      success: res => {
      
      },
      fail: res => {
      
      }
    })
  },

  getOpenID: async function() {
    if (this.openid) {
      return this.openid
    }

    const { result } = await wx.cloud.callFunction({
      name: 'login',
    })

    return result.openid
  },

  onGetUserInfo: function(e) {
    if (!this.logged && e.detail.userInfo) {
      this.setData({
        logged: true,
        avatarUrl: e.detail.userInfo.avatarUrl,
        userInfo: e.detail.userInfo
      })
    }
  },

  onShareAppMessage() {
    // return {
    //   title: '即时通信 Demo',
    //   path: '/pages/im/room/room',
    // }
  },


  getUserInfo: function(e) {

    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },


    //滑动切换
    swiperTab: function (e) {
      var that = this;
      that.setData({
        currentTab: e.detail.current
      });
    },
    //点击切换
    clickTab: function (e) {
      var that = this;
      if (this.data.currentTab === e.target.dataset.current) {
        return false;
      } else {
        that.setData({
          currentTab: e.target.dataset.current
        })
      }
    },

    

    regionchange(e) {

    },

    markertap(e) {
      var that=this;
    
      switch(e.detail.markerId){
        case 0:
          this.setData({
            maplatitude: 30.8,
            maplongitude: 118,      
          })

         that.setData({
           mapscale: 7
         })
         setTimeout(function(){
          that.setData({
            markers:[{
                id: 1,
                latitude: 29.75 ,
                longitude: 118.36,
                width: 50,
                height: 50,

                callout: {
                  content: '黄山市',  //文本
                  color: '#FF0202',  //文本颜色
                  borderRadius: 3,  //边框圆角
                  borderWidth: 1,  //边框宽度
                  borderColor: '#FF0202',  //边框颜色
                  bgColor: '#ffffff',  //背景色
                  padding: 5,  //文本边缘留白
                  textAlign: 'center'  //文本对齐方式。有效值: left, right, center
                }

              },

              { 
                id: 2,
                latitude: 30.95,
                longitude: 118.78,
                width: 50,
                height: 50,

                callout: {
                  content: '宣城市',  //文本
                  color: '#FF0202',  //文本颜色
                  borderRadius: 3,  //边框圆角
                  borderWidth: 1,  //边框宽度
                  borderColor: '#FF0202',  //边框颜色
                  bgColor: '#ffffff',  //背景色
                  padding: 5,  //文本边缘留白
                  textAlign: 'center'  //文本对齐方式。有效值: left, right, center
                }

              },

              { 
                id: 3,
                latitude: 31.35,
                longitude: 118.45,
                width: 50,
                height: 50,

                callout: {
                  content: '芜湖市',  //文本
                  color: '#FF0202',  //文本颜色
                  borderRadius: 3,  //边框圆角
                  borderWidth: 1,  //边框宽度
                  borderColor: '#FF0202',  //边框颜色
                  bgColor: '#ffffff',  //背景色
                  padding: 5,  //文本边缘留白
                  textAlign: 'center'  //文本对齐方式。有效值: left, right, center
                }

              },

              { 
                id: 4,
                latitude: 30.39,
                longitude: 117.29,
                width: 50,
                height: 50,

                callout: {
                  content: '池州市',  //文本
                  color: '#FF0202',  //文本颜色
                  borderRadius: 3,  //边框圆角
                  borderWidth: 1,  //边框宽度
                  borderColor: '#FF0202',  //边框颜色
                  bgColor: '#ffffff',  //背景色
                  padding: 5,  //文本边缘留白
                  textAlign: 'center'  //文本对齐方式。有效值: left, right, center
                }

              },

              { 
                id: 5,
                latitude: 31.75,
                longitude: 116.55,
                width: 50,
                height: 50,

                callout: {
                  content: '六安市',  //文本
                  color: '#FF0202',  //文本颜色
                  borderRadius: 3,  //边框圆角
                  borderWidth: 1,  //边框宽度
                  borderColor: '#FF0202',  //边框颜色
                  bgColor: '#ffffff',  //背景色
                  padding: 5,  //文本边缘留白
                  textAlign: 'center'  //文本对齐方式。有效值: left, right, center
                }
              }]

          })


         },0);
          

  
          break;
        case 1:
                wx.navigateTo({
                  url: './provincesmap/anhuilists?placeid=huangshan',
                })
                break;
        case 2:
                wx.navigateTo({
                  url: './provincesmap/anhuilists?placeid=xuancheng',
                })
                break;
        case 3:
                wx.navigateTo({
                  url: './provincesmap/anhuilists?placeid=wuhu',
                })
                break;
        case 4:
                wx.navigateTo({
                  url: './provincesmap/anhuilists?placeid=chizhou',
                })
                break;
        case 5:
                wx.navigateTo({
                  url: './provincesmap/anhuilists?placeid=liuan',
                })
                break;


        default:
         
      }
    },
    
    recovermap: function(){
      var that=this;
      //this.maporderanime(7,3,0);
      that.setData({
        mapscale: 3
      })

      setTimeout(function(){
        that.setData({
          maplongitude:104,
          maplatitude:20,
          markers:[{ 
              id: 0,
              latitude: 32,
              longitude: 117,
              width: 50,
              height: 70,
              //iconPath:'images/anhui.png',
              callout: {
                content: '安徽省',  //文本
                color: '#FF0202',  //文本颜色
                borderRadius: 3,  //边框圆角
        
                borderWidth: 1,  //边框宽度
                borderColor: '#FF0202',  //边框颜色
                bgColor: '#ffffff',  //背景色
                padding: 5,  //文本边缘留白
                textAlign: 'center'  //文本对齐方式。有效值: left, right, center
              }
            }]
        })
       },125);





    },



    // maporderanime: function(start,end,isincrease=1){
    //   var that=this;
    //   if(start<=end && isincrease==1){
       
    //       that.setData({
    //         mapscale: start
    //       })
    //       that.maporderanime(start+1,end,isincrease);
        
    //   }
    //   else if(start>=end && isincrease==0){

        
    //       that.setData({
    //         mapscale: start
    //       })
    //       that.maporderanime(start-1,end,isincrease);
        
        
    //   }


    // },



    controltap(e) {
   
      wx.getLocation({
        type: 'wgs84',
        success (res) {
          const latitude = res.latitude
          const longitude = res.longitude
          const speed = res.speed
          const accuracy = res.accuracy
         
        }
        
       })
    },

    addnew: function(){
      this.setData({
        isShowConfirm:true
      });
     
    },

    setValue: function (e) {
      this.setData({
        walletPsd: e.detail.value
      })
    },
    cancel: function () {
      var that = this
      that.setData({
        isShowConfirm: false,
      })
    },
    confirmAcceptance:function(){
      var that = this
      that.setData({
        isShowConfirm: false,
      })

      this.onGetOpenid();
    },




  onGetOpenid_joingroup:  function(e) {
    // 调用云函数
   wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {

        
        this.openid2schoolid_joingroup(e,res.result.openid);
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
        return null;
      }
    })
  },

  openid2schoolid_joingroup:  function(e,thisopenid){

    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    return   db.collection('usersdata').where({
      _openid: thisopenid
    }).get({
      success: res => {
        this.setData({
          queryResult: JSON.stringify(res.data, null, 2)
        })

        if(res.data.length==0){
          wx.showToast({
            icon: 'none',
            title: '请先绑定学校账号'
          })
          return null;
        }else{
          
          this.joingroup(res.data[0].schoolid,e);
        }
       // 
     //   return false;
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '网络问题，加入队伍失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
        
        return null;
      }
    })

  },





  joingroup:function(myschoolid,e){
   

    var groupauthor =  e.detail.value.groupauthor;
    
    groupauthor = groupauthor.toString();
    groupauthor = groupauthor.replace("学号: ","");
    
    e.detail.value.groupschoolidbind = e.detail.value.groupschoolidbind.replace("学号: ","");
    var newString = e.detail.value.groupschoolidbind.toString() + "," + myschoolid.toString();

    if(myschoolid.toString()==groupauthor){
      wx.showToast({
        icon:'none',
        title: '您不能加入自己的队伍',
      })
      return;
    }


    const db = wx.cloud.database();
    try{
    db.collection('groupscircle').where({
        schoolidleader: groupauthor
    }).get({  
      success: res => {
      

          
        if(res.data[0].schoolidbind.indexOf(',')==-1){
 
          if(res.data[0].schoolidbind==myschoolid.toString()){
            wx.showToast({
              icon:'none',
              title: '您已在此队伍中',
            })
          }else{
            this.verifiedtojoingroup(groupauthor,newString);
          }
        }else{
   
          var strings = res.data[0].schoolidbind.split(',');
   
          var i;
          for( i=0;i<strings.length;i++){
            if(strings[i]==myschoolid.toString()){
              wx.showToast({
                icon:'none',
                title: '您已在此队伍中',
              })
              break;
            }
          } 
          if(i==strings.length){
            this.verifiedtojoingroup(groupauthor,newString);
          }
        }
        




      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '队伍查询失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }


    })
    }catch(e){

    }

    //verifiedtojoingroup(groupauthor,newString);

    
  },

  verifiedtojoingroup: function(groupauthor,newString){

    const db = wx.cloud.database();
    try{
    db.collection('groupscircle').where({
        schoolidleader: groupauthor
    }).update({

      data: {
        schoolidbind: newString
      },
      
      success: res => {
        wx.showToast({
          icon:'success',
          title: '加入队伍成功'
        })
  
        this.fetchproblemfromdatabase();
      },

      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '加入队伍失败'
        })
    
      }


    })
    }catch(e){

    }

  },

   


  
  fetchproblemfromdatabase: function(){
    var that = this;
    var arr = new Array();

    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    db.collection('groupscircle').get({
      success: res => {
        this.setData({
          queryResult: JSON.stringify(res.data, null, 2)
        })
  
        for(var i=0;i<res.data.length;i++){
          var groupnumber = res.data[i].schoolidbind.split(',').length;

          arr.push({ 
            groupauthor: res.data[i].schoolidleader,
            schoolidbind: res.data[i].schoolidbind,
            groupnumber: groupnumber,
            updatetime:res.data[i].updatetime,
            grouptheme:res.data[i].grouptheme,
            groupauthoricon: res.data[i].groupauthoricon
           });
          

        }
        
        wx.getSystemInfo({
          success: function (res) {
            that.setData({
              //view
              className_height: res.windowHeight / arr.length,
              //btn
              array: arr,
            })
          }
        }) 




      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '队伍查询失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
      }
    })

  },

  jumptochat: function(){
    wx.navigateTo({
      url: 'room/room',
    })
  },

  onGetOpenid:  function() {
   
    // 调用云函数
   wx.cloud.callFunction({
      name: 'login',
      data: {},
      success: res => {

        
        this.openid2schoolid(res.result.openid);
      },
      fail: err => {
        console.error('[云函数] [login] 调用失败', err)
        return null;
      }
    })
  },

  openid2schoolid:  function(thisopenid){

    const db = wx.cloud.database()
    // 查询当前用户所有的 counters
    return   db.collection('usersdata').where({
      _openid: thisopenid
    }).get({
      success: res => {
        this.setData({
          queryResult: JSON.stringify(res.data, null, 2)
        })
  
        if(res.data.length==0){
          wx.showToast({
            icon: 'none',
            title: '请先绑定学校账号'
          })
          return null;
        }else{
          this.submitproblem(res.data[0].schoolid);
        }
       // 
     //   return false;
      },
      fail: err => {
        wx.showToast({
          icon: 'none',
          title: '网络问题，创建队伍失败'
        })
        console.error('[数据库] [查询记录] 失败：', err)
        
        return null;
      }
    })

  },

  submitproblem: function(schoolid){

    var grouptheme = this.data.walletPsd;

    if(!grouptheme || grouptheme.length==0){
      wx.showToast({
        icon:'none',
        title: '请输入队伍名称',
      })

      return;
    }else if(grouptheme.indexOf(' ')!=-1){
      wx.showToast({
        icon:'none',
        title: '队伍名称不应包含空格',
      })

      return;
    }else if(grouptheme.length>10){
      wx.showToast({
        icon:'none',
        title: '队伍名称不能多于10个字',
      })

      return;
    }
    

    
      const db = wx.cloud.database()
      db.collection('groupscircle').add({
        data: {
          //updatetime: getDate(),
          schoolidleader: schoolid.toString(),
          schoolidbind: schoolid.toString(),
          grouptheme:  grouptheme,
          updatetime:"",
          groupauthoricon:this.data.avatarUrl
          //count: 1
        },
        success: res => {

          wx.showToast({
            icon:'success',
            title: '创建队伍成功',
          })
 

          this.fetchproblemfromdatabase();

          setTimeout(function () {
            wx.navigateBack({
              complete: (res) => {},
            })
           }, 1500) 
           
        },
        fail: err => {
          wx.showToast({
            icon: 'none',
            title: '创建队伍失败 您已有队伍'
          })
          console.error('[数据库] [新增记录] 失败：', err)
        }
      })

  }






})
