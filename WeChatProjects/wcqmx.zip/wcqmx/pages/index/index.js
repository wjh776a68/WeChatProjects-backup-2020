//index.js
//获取应用实例
const app = getApp()

Page({

  data: {

   
    currentTab: 0,
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),

    markers: [{ 
      id: 0,
      latitude: 23.099994,
      longitude: 113.324520,
      width: 50,
      height: 50,

      callout: {
        content: '金水区绿地原盛国际1号楼A座9楼',  //文本
        color: '#FF0202',  //文本颜色
        borderRadius: 3,  //边框圆角
        borderWidth: 1,  //边框宽度
        borderColor: '#FF0202',  //边框颜色
        bgColor: '#ffffff',  //背景色
        padding: 5,  //文本边缘留白
        textAlign: 'center'  //文本对齐方式。有效值: left, right, center
      }
    },

    { 
      id: 1,
      latitude: 53.099994,
      longitude: 113.324520,
      width: 50,
      height: 50,

      callout: {
        content: '金水区绿地原盛国际1号楼A座9楼',  //文本
        color: '#FF0202',  //文本颜色
        borderRadius: 3,  //边框圆角
        borderWidth: 1,  //边框宽度
        borderColor: '#FF0202',  //边框颜色
        bgColor: '#ffffff',  //背景色
        padding: 5,  //文本边缘留白
        textAlign: 'center'  //文本对齐方式。有效值: left, right, center
      }

    }

  
  ],

    polyline: [{
      points: [{
        longitude: 113.3245211,
        latitude: 23.10229
      }, {
        longitude: 113.324520,
        latitude: 23.21229
      }],
      color:"#FF0000DD",
      width: 2,
      dottedLine: true
    }],
    controls: [{
      id: 999,
      iconPath: '/images/position.jpg',
      position: {
        left: 0,
        top: 400-50,
        width: 50,
        height: 50
      },
      clickable: true
    }]


  },

  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },

  onLoad: function () {
   // document.getElementById("map").style.height=;
   // this.setData({"mapheight": wx.getSystemInfoSync().screenHeight});
// mapheight: wx.getSystemInfoSync().windowHeight-50,

    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  /*showmap: function(e){
    console.log(e)
    
  },
  showlive: function(e){
    console.log(e)
    
  },
  showregist: function(e){
    console.log(e)
    
  },*/

    //滑动切换
    swiperTab: function (e) {
      var that = this;
      that.setData({
        currentTab: e.detail.current
      });
    },
    //点击切换
    clickTab: function (e) {
      var that = this;
      if (this.data.currentTab === e.target.dataset.current) {
        return false;
      } else {
        that.setData({
          currentTab: e.target.dataset.current
        })
      }
    },

    regionchange(e) {
      console.log(e.type)
    },
    markertap(e) {
      //console.log(e.detail.markerId)
     
      switch(e.detail.markerId){
        case 0:console.log("receive 0");break;
        case 1:console.log("receive 1");break;
        default:
          console.log("error");
      }
    },
    controltap(e) {
      console.log(e.detail.controlId);
      console.log("hello");
      wx.getLocation({
        type: 'wgs84',
        success (res) {
          const latitude = res.latitude
          const longitude = res.longitude
          const speed = res.speed
          const accuracy = res.accuracy
         
        }
        
       })
    }
  

})
